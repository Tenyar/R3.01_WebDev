<?php
header('Location: controler/jukebox.ctrl.php');
