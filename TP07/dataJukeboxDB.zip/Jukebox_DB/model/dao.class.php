<?php
require_once(__DIR__.'/music.class.php');

// Le Data Access Objet
class DAO {
  private $db;

  // Constructeur chargé d'ouvrir la BD
  function __construct() {
    $database = 'sqlite:'.__DIR__.'/../data/music.db';
  }

  // Accès à une musique
  function get(int $id) : Music {
  }

  // Retourne l'idf minimum
  function minId() : int {
  }

  // Retourne l'idf maximum
  function maxId() : int {
  }
}

?>
